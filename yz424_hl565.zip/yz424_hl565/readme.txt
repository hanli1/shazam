Part 1 Shazam Submission
yz424 and hl565

TIME REQUIRED: Assuming the hashTable.mat database is present in the same directory as the main.m file, the expected time to run part1test.m is 300-400 seconds depending on what computer is running the code. On a macbook, our runs average 330-340 seconds.

If hashTable.mat is NOT present, our code has to generate hashTable.mat, which can take upwards of 8-9 minutes. However, we have provided hashTable.mat, so it should not take this long.
